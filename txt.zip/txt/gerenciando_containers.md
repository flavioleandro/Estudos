### Gerenciando container Portainer
----
# Criar volume (para não perder as configurações)
docker volume create portainer_data
# Executando o container portainer
docker run -d -p 1000:9000 -v /var/run/docker.sock:/var/run/docker.sock -v portainer_data:/data portainer/portainer


### Gerenciando container Jenkins
----
# Criar volume (para não perder as configurações)
docker volume create jenkins (-v no docker run monta volume persistente)
docker volume ls |grep jenkins 
docker volume inspect jenkins (visualizando onde o volume está instalado fisicamente)
docker run --name jenkins -d --restart=always -p 8090:8080 -u -v jenkins:/var/jenkins_home jenkins
docker logs jenkins -f
13bb9ea9855a42ccb9b3aef75e05b874 (pegar a senha para add na console)

chown -R 1000 volume_dir

### Gerenciando container Nexus
docker volume create nexus
docker volume ls |grep nexus
docker volume inspect Nexus (visualizando onde o volume está instalado fisicamente)
docker run -d -p 8081:8081 --name nexus -v nexus:/nexus-data sonatype/nexus3

cd /var/lib/docker/volumes
chown -R 200 nexus

#Permissão do SE Linux (permissive)
[root@vvcelpdigdck09:1 ~]# vi /etc/selinux/config
SELINUX=permissive

### Gerenciando container Artifactory
docker volume create artifactory
docker run --name artifactory -d -p 8081:8081 -v /home/volumes/jfrog/data:/var/opt/jfrog/artifactory/data -v /home/volumes/jfrog/logs:/var/opt/jfrog/artifactory/logs -v /home/volumes/jfrog/etc:/var/opt/jfrog/artifactory/etc docker.bintray.io/jfrog/artifactory-oss:latest

### Gerenciando container Sonar
#downalod das imagens
docker pull sonarqube
docker pull postgres

docker volume create sonarqube-postgre
docker volume ls |grep sonar
docker volume inspect sonar (visualizando onde o volume está instalado fisicamente)
docker run --name postgres-sonarcube POSTGRES_DB=sonar -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=sa123@ezvida -p 5555:5432 -d -v postgre-sonarqube:/var/lib/postgresql/data postgres
docker exec -it -u postgres postgres-sonarcube psql
--descobrindo o ip do container
[root@server1 volumes]# docker inspect postgres-sonarcube |grep IPAddress
            "SecondaryIPAddresses": null,
            "IPAddress": "172.17.0.7",
                    "IPAddress": "172.17.0.7",

docker run -d --name sonarqube -p 9000:9000 -e SONARQUBE_JDBC_USERNAME=postgres -e SONARQUBE_JDBC_PASSWORD=sa123@ezvida -e SONARQUBE_JDBC_URL=jdbc:postgresql://sonarqube-postgres/sonar sonarqube
docker logs e760251314e7 -f


  sonarqube-postgres:
    restart: always
    image: postgres
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: sa123@ezvida
      POSTGRES_DB: sonar
    ports:
         - "5555:5432"
    volumes:
        - /var/lib/docker/volumes/sonarqube-postgre:/var/lib/postgresql/data


### Gerenciando container SQL Server
----
# Tamanho do disco
Em casos quando trabalhar com base de dados superior a 51GB é interessante usar alguma distribuição Linux pois há problema de sistema de arquivos no OSX e Windows.

# Criar volumes antes de subir os containers (para não perder as configurações)
cd /var/lib/docker/volumes (visualizar onde é criado os volumes por default, qdo o docker está instalado no server)
ls -l 

# Executar container MsSQL (com volume, mapendo pra um diretório criado "/home/volumes/mssql")
docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=sa123@ezvida' -e 'MSSQL_PID=Enterprise' -p 1433:1433 -d -v /home/volumes/mssql:/var/opt/mssql microsoft/mssql-server-linux:latest

# Criar container de volume
docker volume create mssql-volume

# Executar container mssql (com volume, qdo 2 containers vão utilizar o mesmo volume)
docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=sa123@ezvida' -e 'MSSQL_PID=Enterprise' -p 1433:1433 -d -v mssql-volume:/var/opt/mssql microsoft/mssql-server-linux:latest

# Copiar backup para Docker
docker exec -i 205e34732752 bash -c 'cat > /var/opt/mssql/SST.bak' < ‘/Users/romero.dias/Documents/SST.bak'

# Restaurar backup
RESTORE DATABASE S4_SST FROM DISK = '/var/opt/mssql/S4_SST.bak';

# Ver arquivos do container
docker exec -i 205e34732752 bash -c 'ls -la -h /var/opt/mssql'


### Gerenciando container PostgreSQL
----
# Executar container postgre (com volume, mapeando pra um diretório criado "/home/volumes/postgre")
docker run --name some-postgres -e POSTGRES_PASSWORD=sa123@ezvida -p 5434:5432 -d -v /home/volumes/postgre:/var/lib/postgresql/data postgres

# Criar roles PostgreSQL
CREATE ROLE usr_dba WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_flavia WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_pentaho_dev WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_rede_sesi WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_res_pentaho_dev WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_sesi_rst WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

CREATE ROLE usr_sesi_rst_teste WITH
NOLOGIN
SUPERUSER
INHERIT
CREATEDB
CREATEROLE
NOREPLICATION;

#Configurando uma timezone
docker run -i -t -e TZ=America/Sao_Paulo centos /bin/bash


